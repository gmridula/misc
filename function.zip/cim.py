import json
import requests

def lambda_handler(event, context):
    # TODO implement
    response = requests.get('https://api.github.com/users/caspyin')
    print(response)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
